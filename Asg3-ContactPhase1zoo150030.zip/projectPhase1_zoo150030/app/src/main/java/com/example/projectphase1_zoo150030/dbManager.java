package com.example.projectphase1_zoo150030;

/*
 * Author: Zack Oldham
 * dbManager.java
 * This class defines the database manager which is responsible for retrieving information from,
 * and updating, the "database" text file.
 */



import android.content.Context;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class dbManager
{
    private ArrayList<String> data;
    private File inputFile;

    public dbManager(Context context, String fileName)
    {
        inputFile = new File(context.getFilesDir(), fileName);
        data = new ArrayList<>();
        //writeDB();
    }

    /*
     * Read the database and return the data ArrayList.
     */
    public ArrayList<String> query() throws IOException
    {
        if(readDB())
        {
            return data;
        }

        return null;
    }

    /*
     * Read the database and return the position in it at which the given name pair occurs.
     */
    public String query(String fname, String lname) throws IOException
    {
        if(readDB())
        {
            int position = findContact(fname, lname);
            if(position == -1)
            {
                return null;
            }

            return data.get(position);
        }

        return null;
    }


    /*
     * Read the database, and attempt to find the provided name pair. If found, update the
     * information for that contact. return true if the specified contact was successfully updated,
     * otherwise return false to signify that an error occurred.
     */
    public boolean updateDB(String updates, String first, String last) throws IOException
    {
        if(readDB())
        {
            int position = findContact(first, last);

            if(position != -1)
            {
                data.set(position, updates);
                writeDB();
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }


    /*
     * **Overloaded functionality of updateDB**
     * Read the database contents. If the database is empty, initialize the data ArrayList, add the
     * new contact to it, and write to the database.
     */
    public boolean updateDB(String updates)
    {
        readDB();
        data.add(updates);
        return writeDB();
    }

    /*
     * Delete a contact from the database file
     */
    public boolean deleteContact(String name)
    {
        if(name == null)
        {
            return false;
        }
        else
        {
            readDB();
            String namePair[] = name.split(", ");
            int position = findContact(namePair[1], namePair[0]);

            if(position != -1)
            {
                data.remove(position);
                writeDB();
                return true;
            }

            return false;
        }
    }


    /*
     * Erase all contacts from the database file
     */
    public void eraseDB()
    {
        data.clear();
        writeDB();
    }



    /*
     * Given a first/last name pair, determine if that name pair appears in the file.
     * If so, return its position in the ArrayList, otherwise return -1.
     */
    private int findContact(String first, String last)
    {
        if(data.isEmpty())
        {
            return -1;
        }

        String toks[] = null;

        for(int i = 0; i < data.size(); i++)
        {
            toks = data.get(i).split("\t");

            if(first.compareTo(toks[0]) == 0 && last.compareTo(toks[1]) == 0)
            {
                return i;
            }
        }

        return -1;
    }


    /*
     * Read all of information from the database into the data Arraylist.
     */
    private boolean readDB()
    {
        Scanner in = null;
        data = new ArrayList<>();

        try
        {
            in = new Scanner(inputFile);

            while(in.hasNext())
            {
                data.add(in.nextLine());
            }

            in.close();

        }
        catch(Exception ex)
        {
            return false;
        }

        return true;
    }


    /*
     * Write all of the data in the data ArrayList to the database.
     */
    private boolean writeDB()
    {
        PrintWriter out = null;

        try
        {
            out = new PrintWriter(inputFile);

            for(int i = 0; i < data.size(); i++)
            {
                out.println(data.get(i));
            }

            out.close();
        }
        catch(Exception ex)
        {
            return false;
        }

        return true;
    }
}
