package com.example.projectphase1_zoo150030;

/*
 * Author: Zack Oldham
 * Date: 02-23-2019
 * Project Phase 1
 * This application will consist of a contact manager that allows the user to view their their
 * contacts in a list as well as add or remove contacts. The contact data will be stored in a
 * text file "database".
 */


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity
{
    private final int EXISTING_CONTACT = 0;
    private final int NEW_CONTACT = 1;
    dbManager db;
    private String selectedContact;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //anytime the main activity is brought to the screen, generate the list of contacts from
        //data currently present in the "database" file
        refresh();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    //display the current contents of the database file
    public void refresh()
    {
        listGenerator lg = new listGenerator(true, false, false,null);
        lg.execute("");
    }



    /*
     * When the add contact item is selected from the options list, the second activity will be
     * brought on to the screen in the edit mode so that the user can enter the information for
     * a new contact. Upon returning to the main activity, refresh the list
     */
    public void onAddContact(MenuItem item)
    {
        Intent addIntent = new Intent(this, contactDetails.class);
        addIntent.putExtra("mode", NEW_CONTACT);
        startActivityForResult(addIntent, NEW_CONTACT);
    }


    /*
     * When a contact is selected from the list of contacts, the second activity will be brought
     * up to the screen with the details of the selected contact in the display mode
     * (Cannot be edited). An "edit" button will present should the user decide to edit the
     * presented details.
     */
    public void onSelectContact(View view)
    {
        TextView tv = (TextView)view;
        listGenerator lg = new listGenerator(true, false, false, null);
        selectedContact = tv.getText().toString();
        lg.execute(selectedContact);
    }


    /*
     * Empty the database and refresh the list
     */
    public void onDeleteContacts(MenuItem item)
    {
        listGenerator contacts = new listGenerator(false, true, false, null);
        contacts.execute("");
        refresh();
    }



    /*
     * Check the resultCode returned from the called activity. If a RESULT_OK code is recieved, then
     * proceed to determine which requestCode was sent, and update the database file in corresponding
     * manner.
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        listGenerator lg = null;

        if(resultCode == RESULT_OK)
        {
            if(requestCode == NEW_CONTACT)
            {
                lg = new listGenerator(false, false, false, null);
                lg.execute(data.getStringExtra("newContact"));
            }
            else
            {
                lg = new listGenerator(false, false , false, selectedContact);
                lg.execute(data.getStringExtra("newContact"));
            }
        }
        else
        {
            lg = new listGenerator(false, false, true, null);
            lg.execute(selectedContact);
        }

        refresh();
    }



    /*
     * Class listGenerator
     * The listGenerator asyncTask is used for interacting with the database. This includes updates,
     * specific queries, full queries, deletes, and clearing the database.
     */
    public class listGenerator extends AsyncTask<String, Void, ArrayList<String>>
    {

        private boolean isQuery, isSingleQuery, isClear, isDel, err;
        String origName;


        public listGenerator(boolean q, boolean c, boolean d, String oN)
        {
            isQuery = q;
            isClear = c;
            isDel = d;
            origName = oN;
            isSingleQuery = false;
            err = false;
        }


        /*
         * Determine which command has been issued, and perform that task (clear/query/query specific/update new contact/update existing)
         */
        @Override
        protected ArrayList<String> doInBackground(String... inputs)
        {
            db = new dbManager(MainActivity.this, "db_file.txt");
            ArrayList<String> data = null;

            try
            {
                if(isClear)
                {
                   db.eraseDB();
                   return null;
                }
                else if(isDel)
                {
                    err = !db.deleteContact(selectedContact);
                    return null;
                }
                else if(isQuery)
                {
                    if(!inputs[0].isEmpty())
                    {
                        isSingleQuery = true;
                        String[] namePair = null;
                        data = new ArrayList<>();

                        namePair = inputs[0].split(", ");
                        data.add(db.query(namePair[1], namePair[0]));
                    }
                    else
                    {
                        data = db.query();
                    }

                    return data;
                }
                else
                {
                    if(origName != null)
                    {
                        String orig_namePair[] = origName.split(", ");

                        err = !db.updateDB(inputs[0], orig_namePair[1], orig_namePair[0]);
                    }
                    else
                    {
                        err = !db.updateDB(inputs[0]);
                    }

                    return null;
                }
            }
            catch(Exception ex)
            {
                System.out.println(ex.getMessage());
                err = true;
                return null;
            }
        }

        /*
         *  If the error flag is set and either isQuery or isClear is set, then a display the database
         *  error message. Otherwise just leave the screen blank. If the error flag is not set and isQuery
         *  is set, then determine if it was a specific query. If so, start the contactDetials activity
         *  and send the retrieved contact in an intent. Otherwise, the command was for a full query,
         *  so create a new instance of contactsAdapter and attach it to the listView.
         */
        @Override
        protected void onPostExecute(ArrayList<String> ds)
        {
            ListView lv = findViewById(R.id.contactList);

            if(err)
            {
                lv.setVisibility(lv.INVISIBLE);
                if(isQuery || isClear || isDel)
                {
                    TextView errMsg = findViewById(R.id.errorMsg);
                    errMsg.setVisibility(errMsg.VISIBLE);
                }
            }
            else if(isQuery && ds != null)
            {
                if (!isSingleQuery)
                {
                    contactsAdapter cA = new contactsAdapter(MainActivity.this, R.layout.contacts_layout, ds);
                    lv.setAdapter(cA);
                }
                else
                {
                    Intent displayIntent = new Intent(MainActivity.this, contactDetails.class);
                    displayIntent.putExtra("mode", EXISTING_CONTACT);
                    displayIntent.putExtra("contactData", ds.get(0));

                    startActivityForResult(displayIntent, EXISTING_CONTACT);
                }
            }
        }
    }
}
